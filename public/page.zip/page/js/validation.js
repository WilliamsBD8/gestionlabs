function proceso_fetch(url, data) {
    return fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded', Authentication: 'secret' },
        body: data
    }).then(response => {
        if (!response.ok) throw Error(response.status);
        return response.json();
    }).catch(error => alert("Error"));
}

function validation() {
    Swal.fire({
        title: 'Digite el codigo del certificado.',
        input: 'text',
        inputAttributes: {
            autocapitalize: 'off'
        },
        showCancelButton: true,
        confirmButtonColor: '',
        confirmButtonText: 'Validar',
        cancelButtonText: 'Cancelar',
        showLoaderOnConfirm: true,
        preConfirm: (codigo) => {
            var url = $('form#form-valid').attr('action');
            var data = new URLSearchParams({
                codigo: codigo
            });
            var result = proceso_fetch(url, data.toString());
            result.then(respuesta => {
                console.log(respuesta);
                if (respuesta.response) {
                    Swal.fire({
                        title: 'Certificado encontrado',
                        text: `Certificado N° ${ respuesta.data }`,
                        icon: 'success',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Ver',
                        cancelButtonText: 'Cerrar',
                    }).then((result) => {
                        if (result.isConfirmed) {}
                    })
                } else {
                    Swal.fire({
                        icon: 'warning',
                        title: 'Oops...',
                        text: `No se encontro certificado con codigo ${ codigo }`,
                    })
                }

            })
        },
        allowOutsideClick: () => !Swal.isLoading()
    })
}